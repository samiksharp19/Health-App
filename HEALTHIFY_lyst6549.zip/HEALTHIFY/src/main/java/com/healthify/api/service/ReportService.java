package com.healthify.api.service;

public interface ReportService {

}
