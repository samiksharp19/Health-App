package com.healthify.api.serviceimpl;


import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.healthify.api.dao.AppointmentDao;
import com.healthify.api.dao.DoctorDao;
import com.healthify.api.entity.Appointment;
import com.healthify.api.entity.DoctorsTimeOff;
import com.healthify.api.service.AppointmentService;
import com.healthify.api.utility.OverlapChecker;

/**
 * @author RAM
 *
 */
@Service()
public class AppointmentServiceImp implements AppointmentService {

	@Autowired
	private AppointmentDao appointmentDao;

	@Autowired
	private DoctorDao dao;

	@Override
	public int doctorAvailibilityChecker(String doctorId, Date date, String startTime, String endTime) {

		boolean isDoctorAvailable = false;
		int status = 0;

		// check doctor time off

		List<DoctorsTimeOff> doctorTimeOff = dao.getDoctorTimeOff(doctorId, date);

		if (doctorTimeOff.isEmpty()) {
			// available to take appointment
			status = 1;
			isDoctorAvailable = true;
		} else {
			for (DoctorsTimeOff doctorsTimeOff : doctorTimeOff) {

				boolean isDayOff = doctorsTimeOff.getDayOff();

				if (isDayOff) {
					// day off
					status = 2;
					isDoctorAvailable = false;
					break;
				} else {
					isDoctorAvailable = doctorsTimeOff.getUnavailableTimeSlots().stream()
							.anyMatch(timeOff ->OverlapChecker.isOverlap(
									LocalTime.parse(startTime, DateTimeFormatter.ofPattern("h:mm a")),
									LocalTime.parse(endTime, DateTimeFormatter.ofPattern("h:mm a")),
									LocalTime.parse(timeOff.getStartTime(), DateTimeFormatter.ofPattern("h:mm a")),
									LocalTime.parse(timeOff.getEndTime(), DateTimeFormatter.ofPattern("h:mm a"))));

					if (isDoctorAvailable) {
						// time off
						status = 3;
					} else {
						// available to take appointment
						status = 1;
					}
				}

			}

		}
		// check doctor appointment time
		if (!isDoctorAvailable) {
			List<Appointment> appointments = getAppointmentsByDoctorIdAndAppointmentDate(doctorId, date);
			if (!appointments.isEmpty()) {
				isDoctorAvailable = appointments.stream().anyMatch(appointment -> OverlapChecker.isOverlap(
						LocalTime.parse(startTime, DateTimeFormatter.ofPattern("h:mm a")),
						LocalTime.parse(endTime, DateTimeFormatter.ofPattern("h:mm a")),
						LocalTime.parse(appointment.getAppointmentStartTime(), DateTimeFormatter.ofPattern("h:mm a")),
						LocalTime.parse(appointment.getAppointmentEndTime(), DateTimeFormatter.ofPattern("h:mm a"))));

				if (isDoctorAvailable) {
					// Appointment already taken on this time
					status = 4;
				} else {
					// available to take appointment
					status = 1;
				}
			}

		}
		return status;
	}
	
	

	@Override
	public int scheduleAppointment(Appointment appointment) {

		int status = doctorAvailibilityChecker(appointment.getDoctorId(), appointment.getAppointmentDate(),
				appointment.getAppointmentStartTime(), appointment.getAppointmentEndTime());

		if (status == 1) {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
			LocalDateTime now = LocalDateTime.now();
			String id = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new java.util.Date());
			Date date = Date.valueOf(LocalDate.now());
			appointment.setAppointmentpatientid(id);
			appointment.setAppointmentTakenTime(dtf.format(now));
			appointment.setAppointmentTakenDate(date);

			return appointmentDao.scheduleAppointment(appointment);
		} else {
			return status;
		}
	}

	

	@Override
	public int updateAppointment(Appointment appointment) {
		int status = 0;
		Appointment dbAppointment = getAppointmentById(appointment.getAppointmentpatientid());
		if (dbAppointment != null) {

			int isDoctorAvailable = doctorAvailibilityChecker(appointment.getDoctorId(), appointment.getAppointmentDate(),
					appointment.getAppointmentStartTime(), appointment.getAppointmentEndTime());

			
			if(isDoctorAvailable==1){
				// ready for update
				status = appointmentDao.updateAppointment(appointment);
			}
	
		}else {
			status=6;
		}
		return status;
	}

	@Override
	public Appointment getAppointmentById(String appointmentId) {
		Appointment appointment = appointmentDao.getAppointmentById(appointmentId);
		return appointment;
	}

	@Override
	public List<Appointment> getAppointmentsByPatientsIds(List<Long> patientsId) {
		List<Appointment> appointmentsByPatientsIds = appointmentDao.getAppointmentsByPatientsIds(patientsId);
		return appointmentsByPatientsIds;
	}

	@Override
	public List<Appointment> getAppointmentsByDoctorIdAndAppointmentDate(String doctorId, Date appointmentDate) {
		List<Appointment> appointments = appointmentDao.getAppointmentsByDoctorIdAndAppointmentDate(doctorId,
				appointmentDate);
		return appointments;
	}

	@Override
	public List<Appointment> getAppointmentsByDoctorIdAndAppointmentDate(String doctorId, Date appointmentDate,
			String appointmentTime) {
		List<Appointment> appointments = appointmentDao.getAppointmentsByDoctorIdAndAppointmentDate(doctorId,
				appointmentDate);
		return appointments;
	}

	@Override
	public List<Appointment> getAppointmentsByDate(Date date) {
		List<Appointment> appointmentsByDate = appointmentDao.getAppointmentsByDate(date);
		return appointmentsByDate;
	}

	@Override
	public Long getCountByAppointmentDate(Date appointmentDate) {
		Long countByAppointmentDate = appointmentDao.getCountByAppointmentDate(appointmentDate);
		return countByAppointmentDate;
	}

	@Override
	public List<Appointment> getAppointmentsByBillingDate(Date billingDate) {
		List<Appointment> appointmentsByBillingDate = appointmentDao.getAppointmentsByBillingDate(billingDate);
		return appointmentsByBillingDate;
	}

	@Override
	public Long getAppointmentsTotalCount() {
		Long count = appointmentDao.getAppointmentsTotalCount();
		return count;
	}

	@Override
	public Long getCountByAppointmentTakenDate(Date appointmentTakenDate) {
		Long count = appointmentDao.getCountByAppointmentTakenDate(appointmentTakenDate);
		return count;
	}

	@Override
	public Long getCountByTreatmentStatusAndBillingDate(String treatmentStatus, Date billingDate) {
		Long count = appointmentDao.getCountByTreatmentStatusAndBillingDate(treatmentStatus, billingDate);
		return count;
	}

	@Override
	public List<Appointment> getAllAppointments() {
		List<Appointment> allAppointments = appointmentDao.getAllAppointments();
		return allAppointments;
	}

	@Override
	public List<Appointment> getTop5AppointmentsByDate(Date date) {
		List<Appointment> top5AppointmentsByDate = appointmentDao.getTop5AppointmentsByDate(date);
		return top5AppointmentsByDate;
	}

	@Override
	public Appointment appointmentAvailibityChecker() {
		// TODO Auto-generated method stub
		return null;
	}

}
