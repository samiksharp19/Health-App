package com.healthify.api.model;

public class MedicineInfoReport {

	private String medicineName;
	private int medicineQty;
	private double medicinePrice;
	private double total;
}
