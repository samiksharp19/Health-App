package com.healthify.api.controller;


import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.healthify.api.entity.DoctorsTimeOff;
import com.healthify.api.exception.ResourceAlreadyExistsException;
import com.healthify.api.exception.ResourceNotFoundException;
import com.healthify.api.service.DoctorService;


/**
 * @author RAM
 *
 */
@RestController
@RequestMapping(value = "/doctor")
public class DoctorController {
	
	private static Logger log = LogManager.getLogger(DoctorController.class);
	
	@Autowired
	private DoctorService service;
	
	@PostMapping(value = "/set-time-off",produces = {"application/json"})
	public ResponseEntity<String> setTimeOff(@RequestBody @Valid DoctorsTimeOff doctorsTimeOff) {
		
		int status = service.setTimeOff(doctorsTimeOff);
		
		if (status == 1) {

			return new ResponseEntity<String>("Time Off Added Successfully.",HttpStatus.CREATED);
		} else if (status == 2) {
			throw new ResourceAlreadyExistsException("Time Off Updated");
		} else if(status==3){
			return new ResponseEntity<String>("Appointment is already scheduled on this time, You cant create or update timeoff",HttpStatus.CONFLICT);
		}else {
			return new ResponseEntity<String>("Something went wrong",HttpStatus.INTERNAL_SERVER_ERROR);
		}
				
	}
	
	
	@GetMapping(value = "/get-time-off/{doctorUsername}",produces = {"application/json"})
	public ResponseEntity<Object> getDoctorTimeOff(@PathVariable String doctorUsername){
		
		List<DoctorsTimeOff> doctorTimeOff = service.getDoctorTimeOff(doctorUsername);
		if(!doctorTimeOff.isEmpty()) {
			return new ResponseEntity<Object>(doctorTimeOff,HttpStatus.OK);
		}else {
			throw new ResourceNotFoundException("The doctor is available today all day");
		}
		
	}
	
}
