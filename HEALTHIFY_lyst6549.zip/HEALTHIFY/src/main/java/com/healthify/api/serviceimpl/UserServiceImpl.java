package com.healthify.api.serviceimpl;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.StringJoiner;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.healthify.api.dao.UserDao;
import com.healthify.api.entity.Role;
import com.healthify.api.entity.User;
import com.healthify.api.model.UserReport;
import com.healthify.api.security.CustomUserDetail;
import com.healthify.api.service.UserService;
import com.twilio.rest.chat.v1.service.UserReader;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	public BCryptPasswordEncoder passwordEncoder;

	@Autowired
	private UserDao dao;

	@Value("${user.roles}")
	private String[] roles;

	@Override
	public boolean addUser(User user) {
		Date date = Date.valueOf(LocalDate.now());
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setCreatedDate(date);
		user.setPassword(encodedPassword);

		if (user.getSpecialties() != null) {
			user.getSpecialties().forEach(speciality -> {
				speciality.setUser(user);
				speciality.setName(speciality.getName().toUpperCase());
			});
		}

		boolean isAdded = dao.addUser(user);

		return isAdded;
	}

	@Override
	public User loginUser(User user) {

		return dao.loginUser(user);
	}

	@Override
	public CustomUserDetail loadUserByUserId(String userId) {
		return dao.loadUserByUserId(userId);
	}

	@Override
	public boolean deleteUserById(String id) {
		return dao.deleteUserById(id);
	}

	@Override
	public User getUserById(String id) {
		User user = dao.getUserById(id);
		if(user!=null) {
			user.setPassword("******");
		}
	
		return user;
	}

	@Override
	public List<User> getAllUsers() {

		List<User> userList = dao.getAllUsers();

		List<User> distinctUserList = userList.stream()
				.collect(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(User::getUsername)))).stream()
				.collect(Collectors.toList());

		return distinctUserList;
	}

	@Override
	public User updateUser(User user) {
		String password = passwordEncoder.encode(user.getPassword());
		user.setPassword(password);
		if (user.getSpecialties() != null) {
			user.getSpecialties().forEach(speciality -> {
				speciality.setUser(user);
				speciality.setName(speciality.getName().toUpperCase());
			});
		}
//		Set<Role> roles = user.getRoles();
//		List<Role> list=new ArrayList<>(roles);
//		Set<Role> updatedRoles = new HashSet<>();
//		user.getRoles().clear();
//		for (Role role : list) {
//			Role userRole = getRoleById(role.getId());
//			updatedRoles.add(userRole);	
//		}
//		user.setRoles(updatedRoles);
		User updatedUser = dao.updateUser(user);
		
		return updatedUser;
	}

	@Override
	public Long getUsersTotalCounts() {
		return dao.getUsersTotalCounts();
	}

	@Override
	public Long getUsersTotalCounts(String type) {
		type = "ROLE_" + type.toUpperCase();
		return dao.getUsersTotalCounts(type);
	}

	@Override
	public List<User> getUserByFirstName(String firstName) {
		return dao.getUserByFirstName(firstName);
	}

	@Override
	public Role addRole(Role role) {

//		boolean contains = Arrays.stream(roles).anyMatch(role.getName()::equals);
//		if (contains) {
//			return dao.addRole(role);
//		} else {
//			return null;
//		}
		
		return dao.addRole(role);

	}

	@Override
	public Role getRoleById(int roleId) {

		return dao.getRoleById(roleId);
	}

	@Override
	public String generateReport() {
		List<User> allUsers = getAllUsers();
		List<UserReport> userReportsList=new ArrayList<UserReport>();
		UserReport userReport=null;
		for (User user : allUsers) {
			userReport=new UserReport();
			userReport.setFirstName(user.getFirstname());
			userReport.setLastName(user.getLastname());
			userReport.setEmailId(user.getEmailid());
			userReport.setMobile(user.getMobileno());
			
			String role="";

			Set<Role> roles = user.getRoles();
			role = roles.stream()
            .map(userRole -> userRole.getName().substring(5))
            .collect(Collectors.joining(", "));
			
			userReport.setRole(role);
			
			userReportsList.add(userReport);
		}
		
		String filePath=null;
		try {
			// Fetching the .jrxml file from the resources folder.
			//InputStream is=new FileInputStream("src/main.resources/user list.jrxml");
			final InputStream stream = this.getClass().getResourceAsStream("/user list.jrxml");

			// Compile the Jasper report from .jrxml to .japser
			final JasperReport report = JasperCompileManager.compileReport(stream);

			// Fetching the employees from the data source.
			final JRBeanCollectionDataSource source = new JRBeanCollectionDataSource(userReportsList);

			// Filling the report with the employee data and additional parameters
			// information.
			final JasperPrint print = JasperFillManager.fillReport(report, null, source);

			// final String filePath = "C:\\Users\\RAM\\Downloads\\";
			 filePath = System.getProperty("user.home");
			// Export the report to a PDF file.
			JasperExportManager.exportReportToPdfFile(print, filePath + "/Downloads/UserTemp.pdf");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return filePath+"/Downloads/UserTemp.pdf";
	}

}
