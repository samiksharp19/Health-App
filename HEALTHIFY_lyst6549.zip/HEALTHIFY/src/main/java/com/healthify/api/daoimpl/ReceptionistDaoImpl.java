package com.healthify.api.daoimpl;

import java.sql.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.healthify.api.dao.ReceptionistDao;
import com.healthify.api.entity.DoctorsTimeOff;

@Repository
public class ReceptionistDaoImpl implements ReceptionistDao {
	@Autowired
	private SessionFactory sf;

	private static Logger log = LogManager.getLogger(ReceptionistDaoImpl.class);

	@Override
	public DoctorsTimeOff checkDoctorTimeOff(String doctorName, Date date) {
		Session session = sf.getCurrentSession();
		try {

			Criteria criteria = session.createCriteria(DoctorsTimeOff.class);
			SimpleExpression doctor = Restrictions.eq("doctorUserame", doctorName);
			SimpleExpression timeOffDate = Restrictions.eq("timeOffDate", date);
			criteria.add(Restrictions.and(doctor, timeOffDate));

			List<DoctorsTimeOff> list = criteria.list();
			if (!list.isEmpty()) {

				DoctorsTimeOff doctorsTimeOff = list.get(0);
					return doctorsTimeOff;


			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("{}", e.getMessage());
		}
		return null;
	}

}
