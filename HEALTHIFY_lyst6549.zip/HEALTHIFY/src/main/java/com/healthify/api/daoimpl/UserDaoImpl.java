package com.healthify.api.daoimpl;

import java.sql.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Repository;

import com.healthify.api.dao.UserDao;
import com.healthify.api.entity.Otp;
import com.healthify.api.entity.Role;
import com.healthify.api.entity.Specialty;
import com.healthify.api.entity.User;
import com.healthify.api.security.CustomUserDetail;

@Repository
public class UserDaoImpl implements UserDao {
	private static Logger LOG = LogManager.getLogger(UserDaoImpl.class);

	@Autowired
	private SessionFactory sf;

	@Autowired
	public PasswordEncoder passwordEncoder;

	@Override
	public boolean addUser(User user) {
		Session session = sf.getCurrentSession();
		boolean isAdded = false;
		try {
			User usr = session.get(User.class, user.getUsername());
			if (usr == null) {
				session.save(user);
				isAdded = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return isAdded;
	}

	@Override
	public User loginUser(User user) {
		Session session = sf.getCurrentSession();
		User usr = null;
		try {
			usr = session.get(User.class, user.getUsername());
			boolean matches = passwordEncoder.matches(user.getPassword(), usr.getPassword());
			if (matches) {
				return usr;
			} else {
				usr = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return usr;

	}

	@Override
	public CustomUserDetail loadUserByUserId(String userId) {
		Session session = sf.getCurrentSession();
		CustomUserDetail user = new CustomUserDetail();
		User usr = null;
		try {
			usr = session.get(User.class, userId);
			if (usr != null) {
				user.setUserid(usr.getUsername());
				user.setPassword(usr.getPassword());
				user.setRoles(usr.getRoles());
			}
			System.out.println("load user ..." + user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public boolean deleteUserById(String id) {
		Session session = sf.getCurrentSession();
		boolean isDeleted = false;
		try {
			User user = getUserById(id);
			if (user != null) {
				session.delete(user);
				isDeleted = true;
			}
		} catch (Exception e) {
			LOG.info(e.getMessage());
			e.printStackTrace();
		}
		return isDeleted;
	}

	@Override
	public User getUserById(String id) {
		Session session = sf.getCurrentSession();
		User user = null;
		try {
			user = session.get(User.class, id);
		} catch (Exception e) {
			LOG.info(e.getMessage());

		}
		return user;
	}

	@SuppressWarnings({ "deprecation", "unchecked" })
	@Override
	public List<User> getAllUsers() {
		Session session = sf.getCurrentSession();
		List<User> list = null;
		try {
			list = session.createCriteria(User.class).list();
		} catch (Exception e) {
			LOG.info(e.getMessage());
		}
		return list;
	}

	@Override
	public User updateUser(User user) {
		Session session = sf.getCurrentSession();
		User dbuser = null;
		boolean isUpdated = false;
		try {
			dbuser = getUserById(user.getUsername());
			if (dbuser != null) {

				try (Session sesn = sf.openSession()) {

					Criteria criteria = session.createCriteria(Specialty.class);
					criteria.add(Restrictions.eq("user.username", user.getUsername()));

					List<Specialty> list = criteria.list();

					if (!list.isEmpty()) {
						for (Specialty specialty : list) {
							sesn.delete(specialty);
							sesn.beginTransaction().commit();
						}
					}

					session.evict(dbuser);
					session.update(user);
					isUpdated = true;

				} catch (Exception e) {
					e.printStackTrace();
				}

			}
			if (isUpdated == false) {
				user = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return user;
	}

	@Override
	public Long getUsersTotalCounts() {
	    Long count = 0L;
	    try {
	        CriteriaBuilder criteriaBuilder = sf.getCriteriaBuilder();
	        CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
	        Root<User> root = criteriaQuery.from(User.class);

	        criteriaQuery.select(criteriaBuilder.count(root));

	        Session session = sf.getCurrentSession();
	        count = session.createQuery(criteriaQuery).uniqueResult();

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return count;
	}


	@Override
	public Long getUsersTotalCounts(String type) {
		long count = 0;
		
		try {
			Session session = sf.getCurrentSession();
			@SuppressWarnings("deprecation")
			Criteria criteria = session.createCriteria(User.class).createAlias("roles", "role")
					.add(Restrictions.eq("role.name", type)).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

			count = (Long) criteria.setProjection(Projections.rowCount()).uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}



	@Override
	public List<User> getUserByFirstName(String firstName) {
	    List<User> list = null;
	    try {
	        CriteriaBuilder criteriaBuilder = sf.getCriteriaBuilder();
	        CriteriaQuery<User> criteriaQuery = criteriaBuilder.createQuery(User.class);
	        Root<User> root = criteriaQuery.from(User.class);

	        criteriaQuery.select(root)
	                .where(criteriaBuilder.equal(root.get("firstname"), firstName));

	        Session session = sf.getCurrentSession();
	        list = session.createQuery(criteriaQuery).getResultList();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return list;
	}


	@Override
	public boolean saveOtp(Otp otp) {
		Session session = sf.getCurrentSession();
		boolean isAdded = false;
		try {
			session.saveOrUpdate(otp);
			isAdded = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isAdded;
	}

	@Override
	public Otp getOtpByUser(String userId) {
		Session session = sf.getCurrentSession();
		Otp otp = null;
		try {
			otp = session.get(Otp.class, userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return otp;
	}

	@Override
	public Role addRole(Role role) {
		Session session = sf.getCurrentSession();
		boolean isAdded = false;
		try {
			session.saveOrUpdate(role);
			isAdded = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (isAdded) {
			return role;
		} else {
			return null;
		}
	}

	@Override
	public Role getRoleById(int roleId) {
		Session session = sf.getCurrentSession();
		Role role = null;
		try {
			role = session.get(Role.class, roleId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return role;
	}

}
