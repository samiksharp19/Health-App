// Java Program to Illustrate Creation Of
// Service implementation class

package com.healthify.api.serviceimpl;

import java.sql.Timestamp;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.healthify.api.dao.UserDao;
import com.healthify.api.entity.Otp;
import com.healthify.api.entity.User;
import com.healthify.api.model.EmailDetails;
import com.healthify.api.model.ResetPasswordDetail;
import com.healthify.api.service.EmailPasswordService;
import com.healthify.api.service.UserService;
import com.healthify.api.utility.OTPGenerator;

@Service
public class EmailPasswordServiceImpl implements EmailPasswordService {
	private static Logger LOG = LogManager.getLogger(EmailPasswordServiceImpl.class);

	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	private UserDao userDao;

	@Autowired
	private UserService userService;

	@Value("${spring.mail.username}")
	private String sender;

	// Method 1
	// To send a simple email
	public boolean sendMail(EmailDetails details) {
		boolean isSent = false;
		try {
			SimpleMailMessage mailMessage = new SimpleMailMessage();
			mailMessage.setFrom(sender);
			mailMessage.setTo(details.getRecipient());
			mailMessage.setText(details.getMsgBody());
			mailMessage.setSubject(details.getSubject());

			javaMailSender.send(mailMessage);
			isSent = true;
		}

		catch (MailException e) {
			isSent = false;
		} catch (Exception e) {
			e.printStackTrace();
			isSent = false;
		}
		return isSent;
	}

	@Override
	public String resetPasswordByQA(ResetPasswordDetail detail) {
		String message = null;
		try {
			User user = userDao.getUserById(detail.getUserId());
			if (user != null) {
				if (detail.getQuestion().equals(user.getQuestion()) && detail.getAnswer().equals(user.getAnswer())) {
					if (detail.getNewPassword().equals(detail.getConfirmPassword())) {
						user.setPassword(detail.getNewPassword());
						User updatedUser = userService.updateUser(user);
						if (updatedUser != null) {
							message = "Password Updated Successfully";
						} else {

							message = "Error While Updating Password";
							LOG.info(message);
						}
					} else {
						message = "New & Confirm Password Must Be Same";
					}
				} else {
					LOG.info("Wrong Security Q & A");
					message = "Wrong Security Q & A";
				}
			} else {
				message = "User Not Exists With Id > " + detail.getUserId();
			}

		} catch (Exception e) {
			LOG.error(e);
			e.printStackTrace();
		}
		return message;
	}

	@Override
	public String sendOtp(String UserId) {
		String msg = null;

		try {
			User user = userDao.getUserById(UserId);
			if (user != null) {
				Date date = new Date();
				Timestamp timestamp = new Timestamp(date.getTime());
				int generatedOtp = OTPGenerator.generateOtp();
				Otp otp = new Otp();
				otp.setUserId(UserId);
				otp.setOtp(generatedOtp);
				otp.setTimestamp(timestamp);
				boolean isAdded = userDao.saveOtp(otp);
				if (isAdded) {
					EmailDetails details = new EmailDetails();
					details.setRecipient(user.getEmailid());
					details.setSubject("HEALTHIFY : Please Verify Your OTP");
					details.setMsgBody("Hey " + UserId + "\n\n Your OTP : " + generatedOtp + "\n\n Otp generated at : "
							+ timestamp);
					boolean isSent = sendMail(details);
					if (isSent) {
						msg = "Otp Has Been Sent To Email > " + user.getEmailid();
					} else {
						msg = "Error Occured While Sending OTP On " + user.getEmailid()
								+ "! \n Check Email Address Of User " + UserId;
					}

				} else {
					msg = "Something Wrong While Save OTP";
				}

			} else {
				msg = "User Not Exists ID > " + UserId;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return msg;
	}

	@Override
	public String resetPasswordByOtp(ResetPasswordDetail detail) {
		String message = null;
		try {

			User user = userDao.getUserById(detail.getUserId());

			if (user != null) {
				Otp dbOtp = userDao.getOtpByUser(detail.getUserId());
				if (dbOtp != null) {
					if (dbOtp.getOtp() == detail.getOtp()) {
						if (detail.getNewPassword().equals(detail.getConfirmPassword())) {
							user.setPassword(detail.getNewPassword());
							User updatedUser = userService.updateUser(user);
							if (updatedUser != null) {
								message = "Password Updated Successfully";
							} else {
								message = "Error While Updating Password";
							}
						} else {
							message = "New & Confirm Password Must Be Same";
						}

					} else {
						message = "Invalid OTP !!";
					}
				} else {
					message = "Otp Not Found For User : " + detail.getUserId() + " Generate Otp First";
				}
			} else {
				message = "USer Not Exists UserId : " + detail.getUserId();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return message;
	}

}
