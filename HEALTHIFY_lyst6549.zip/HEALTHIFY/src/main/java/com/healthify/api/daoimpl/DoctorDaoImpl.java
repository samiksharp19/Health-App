package com.healthify.api.daoimpl;

import static org.hamcrest.CoreMatchers.isA;

import java.sql.Date;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.healthify.api.dao.DoctorDao;
import com.healthify.api.entity.Appointment;
import com.healthify.api.entity.DoctorsTimeOff;
import com.healthify.api.entity.Slots;
import com.healthify.api.service.AppointmentService;
import com.healthify.api.service.ReceptionistService;
import com.healthify.api.serviceimpl.AppointmentServiceImp;

@Repository
public class DoctorDaoImpl implements DoctorDao {

	private static Logger log = LogManager.getLogger(DoctorDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private ReceptionistService receptionistService;

	@Autowired
	private AppointmentServiceImp appointmentService;

	public boolean isAppointmentAlreadyBooked(String doctorId, Date date, String startTime, String endTime) {
		boolean isAppointmentScheduled = false;
		List<Appointment> appointments = appointmentService.getAppointmentsByDoctorIdAndAppointmentDate(doctorId, date);
		if (!appointments.isEmpty()) {
			isAppointmentScheduled = appointments.stream().anyMatch(appointment -> isOverlap(
					LocalTime.parse(startTime, DateTimeFormatter.ofPattern("h:mm a")),
					LocalTime.parse(endTime, DateTimeFormatter.ofPattern("h:mm a")),
					LocalTime.parse(appointment.getAppointmentStartTime(), DateTimeFormatter.ofPattern("h:mm a")),
					LocalTime.parse(appointment.getAppointmentEndTime(), DateTimeFormatter.ofPattern("h:mm a"))));

		}
		return isAppointmentScheduled;

	}

	private static boolean isOverlap(LocalTime start1, LocalTime end1, LocalTime start2, LocalTime end2) {
		return start1.isBefore(end2) && end1.isAfter(start2);
	}

	@Override
	public int setTimeOff(DoctorsTimeOff doctorsTimeOff) {
		int status = 0;
		DoctorsTimeOff doctorsTimeOffDB = receptionistService.checkDoctorTimeOff(doctorsTimeOff.getDoctorUserame(),
				doctorsTimeOff.getTimeOffDate());
		try {
			Session session = sessionFactory.getCurrentSession();
			Set<Slots> unavailableTimeSlots = doctorsTimeOff.getUnavailableTimeSlots();
			List<Boolean> appointStatus = new ArrayList<Boolean>();
			for (Slots slots : unavailableTimeSlots) {

				appointStatus.add(isAppointmentAlreadyBooked(doctorsTimeOff.getDoctorUserame(),
						doctorsTimeOff.getTimeOffDate(), slots.getStartTime(), slots.getEndTime()));
			}
			if (doctorsTimeOffDB == null) {

				
				
				if(appointStatus.contains(true)) {
					status =3;
				}else {
					session.save(doctorsTimeOff);
					status = 1;
				}
			} else {
				
				if(appointStatus.contains(true)) {
					status =3;
				}else {
					session.delete(doctorsTimeOffDB);
					session.save(doctorsTimeOff);
					status = 2;
				}
				
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("{}", e.getMessage());
			status = 3;
		}
		return status;
	}

	@SuppressWarnings({ "deprecation", "unchecked" })
	public List<DoctorsTimeOff> getDoctorTimeOff(String doctorUsername, Date date) {

		List<DoctorsTimeOff> list = null;
		try (Session session = sessionFactory.openSession()) {

			Criteria criteria = session.createCriteria(DoctorsTimeOff.class);
			SimpleExpression doctorId = Restrictions.eq("doctorUserame", doctorUsername);
			SimpleExpression timeOffDate = Restrictions.eq("timeOffDate", date);
			criteria.add(Restrictions.and(doctorId, timeOffDate));

			list = criteria.list();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;

	}

	@Override
	public List<DoctorsTimeOff> getDoctorTimeOff(String doctorUsername) {
		List<DoctorsTimeOff> doctorsTimeOff = null;
		try (Session session = sessionFactory.openSession()) {

			Criteria criteria = session.createCriteria(DoctorsTimeOff.class);
			criteria.add(Restrictions.eq("doctorUserame", doctorUsername));

			doctorsTimeOff = criteria.list();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return doctorsTimeOff;
	}

}
